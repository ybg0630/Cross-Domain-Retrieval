# 成员 4 → 成员 5：完整重排序交付包

六组正式实验全部完成，共 **2,904 条查询、290,400 个查询-文档对**。全部对均实际推理，无小样本混入，也没有用缓存读取时间冒充推理耗时。

## 结果

| 数据集 | 划分 | 查询数 | 混合 nDCG@10 | 重排 nDCG@10 | Δ | 平均重排 ms/查询 | 变好/变差/不变 |
|---|---|---:|---:|---:|---:|---:|---|
| scifact | test | 300 | 0.6815 | 0.6876 | +0.0061 | 239.03 | 60/52/188 |
| scifact | train | 809 | 0.7032 | 0.7110 | +0.0079 | 234.03 | 165/129/515 |
| nfcorpus | test | 323 | 0.3256 | 0.3453 | +0.0198 | 237.31 | 118/85/120 |
| nfcorpus | dev | 324 | 0.3173 | 0.3287 | +0.0114 | 253.20 | 110/92/122 |
| fiqa | test | 648 | 0.3820 | 0.3730 | -0.0090 | 177.12 | 169/204/275 |
| fiqa | dev | 500 | 0.4013 | 0.3836 | -0.0176 | 178.48 | 126/150/224 |

所有划分的 Recall@100 在重排前后完全相同，具体数值见 reports/member4/summary.csv。完整精度见各组 metrics.json。
本次 test 中 SciFact 和 NFCorpus 的平均 nDCG@10 提升，FiQA 下降。不能默认每个查询都会受益；结合校准集 Δ 设计策略，test 结果仅用于最终报告。

## 给成员 5 的文件

- `results/`：六组混合候选和全量重排结果，格式都是 `{查询ID: {文档ID: 得分}}`。
- `cache/`：六组 JSON 得分快照与 SQLite 断点缓存。JSON 可直接在 Mac/Windows 读取，不需要模型。
- `inputs/{dataset}/{split}/`：相同查询集合的 `bm25.json`、`dense.json`（MiniLM）、`queries.json`、`qrels.json`，供计算重合度、查询长度和评估。
- `reports/member4/`：逐查询 Δ、每查询耗时、每对平均耗时、硬件与参数、变化比例图、汇总 CSV 和 test 总览图。
- `member5_io.py`：只依赖 Python 标准库的读取、结果选择与成本模拟接口。
- `source/`：本次运行代码和全部已保存的上游候选。需要复现模型推理时进入 source，安装 requirements-member4.txt，运行 README 中的复现命令。原始语料和模型权重首次运行下载，不随包重复发送。
- `MANIFEST.json`、`VALIDATION.json`、`SHA256SUMS.txt`：模型版本、上游 Git 提交、验证记录和逐文件校验值。

命名：test 用 `scifact_hybrid_rerank.json`；校准集用 `scifact_train_hybrid_rerank.json`、`nfcorpus_dev_hybrid_rerank.json`、`fiqa_dev_hybrid_rerank.json`。

## 直接读取和模拟

在解压目录执行：

```python
from member5_io import load_bundle, choose_results, estimate_cost
bundle = load_bundle('scifact', 'train')
# selected_ids 应由你的信号和阈值策略决定，下面只是全量重排对照。
selected_ids = set(bundle['queries'])
run = choose_results(bundle, selected_ids)
cost = estimate_cost(bundle, selected_ids)
print(cost['mean_extra_rerank_ms'], cost['rerank_fraction'])
# 用小组 utils.evaluate(bundle['qrels'], run) 计算质量。
```

`bundle` 包含 queries、qrels、bm25、dense、hybrid、reranked、rerank_ms、metadata。函数不会训练模型，也不会用 qrels 决定是否重排。

**阈值在 SciFact train / NFCorpus dev / FiQA dev 上选；test 仅用于最终报告。** 每条 Δ 已提供，train/dev 可用于分析信号；不能根据 test 的 Δ 直接选测试查询或阈值。

## 耗时口径

硬件为 NVIDIA GeForce RTX 3070 Ti Laptop GPU（8 GB），batch size 32，CPU 线程 4，最大联合输入长度 512。使用同一个 GPU、模型和参数完成全部六组。
计时使用成员 1 的 Timer，包含分词、模型推理和分数传回 CPU；不含模型加载/预热、上游检索、读写缓存或绘图。每条查询完整处理 100 篇。
`timing.csv` 的 inference_ms 是逐查询实测；`timing.json` 的 ms_per_inferred_pair 是总推理毫秒/总对数，batch_size 和 hardware 也在其中。
`estimate_cost` 将选中查询的实测重排时间相加，再除以**全部查询数**。这是离线成本模拟，不是重新测量在线服务。也可用每对平均耗时 × 100 × 重排比例作较粗估计。
当前包提供的是**额外重排耗时**。画总检索耗时曲线还需同机测量混合检索耗时；不要直接加上成员 2 在 Mac CPU 上的旧耗时。纯 CPU、MPS 或其他 GPU 上的推理成本需要重新测量。

## 验证和复现

```bash
python -B check_handoff.py
# 已装 s1 的评估依赖时，另外复核公共评估指标：
python -B check_handoff.py --evaluate
```

复现 GPU 实验（Windows/Linux 且有兼容 NVIDIA 驱动）：

```bash
cd source
python -m pip install -r requirements-member4.txt
python -m pip install torch==2.14.1 --index-url https://download.pytorch.org/whl/cu126
python run_member4.py --download --device cuda --batch-size 32 --threads 4 --max-length 512 --revision 233902d25c440f23af6f7d6e94d2946bac0bee0a --output-dir ../reproduced
```

成员 5 只做离线策略时无需安装 CUDA。不要把缓存里的 logits 与混合检索分数跨方法直接比较或相加；每条查询选择整份混合排序或整份重排序。

本交付包未包含可选的 top-20/50 消融，完整 top-100 主实验和校准数据均已提供。
